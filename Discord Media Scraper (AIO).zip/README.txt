github.com/xoela
xyl.lol/z

(THIS WAS MADE IN DISCORD.PY 1.7.3 I DON'T KNOW IF IT WORKS FOR NEWER DISCORD.PY VERSIONS)

The neccesary packages to install are:

discord.py (1.7.3)
colorama

Please replace your token in config.json.
Create a folder with "main.py" and "config.json" and in that folder create a folder called "media" (if not included in the zip)

If you wish to have a different directory for the media files please change it in line 38
or (and) if you wish to have more extensions or remove extensions please change them in line 37

Dont mind the shitty code, was first time making something

If you experience any errors or have any questions, message me at telegram (@koorts) or discord (zex#1234)

(THIS WAS MADE IN DISCORD.PY 1.7.3 I DON'T KNOW IF IT WORKS FOR NEWER DISCORD.PY VERSIONS)

github.com/xoela
xyl.lol/z

